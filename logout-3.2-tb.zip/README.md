# logout
Thunderbird extension

This extension lets you logout from single accounts without closing Thunderbird.
It adds "Logout" to the folders context menu.
After you "Logout" you will be asked again for passwords for this account (incoming and outgoing).

https://addons.thunderbird.net/de/thunderbird/addon/logout/
